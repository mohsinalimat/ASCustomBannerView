//
//  ViewController.swift
//  ASCustomBannerView
//
//  Created by Alan Roldán Maillo on 25/6/16.
//  Copyright © 2016 Alan Roldán Maillo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var baner: BannerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        baner.createBanner(["bnr1","bnr2","bnr3","bnr5"], widthScreen: UIScreen.mainScreen().bounds.width)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

